using System;
using System.Linq;
using AvatarVcs.Runtime;
using UnityEditor;
using UnityEngine;

namespace AvatarVcs.Editor.Core
{
    /// <summary>
    /// Creation and lookup of the "[AvatarVCS]" root and its containers.
    /// Design doc sections 1.1, 1.3.1, 1.3.2.
    /// </summary>
    public static class ContainerManager
    {
        public const string RootName = "[AvatarVCS]";

        /// <summary>
        /// Finds the existing management root under avatarRoot, or creates one.
        /// Safe to call repeatedly: never creates a duplicate.
        /// </summary>
        public static GameObject EnsureRoot(GameObject avatarRoot)
        {
            if (avatarRoot == null) throw new ArgumentNullException(nameof(avatarRoot));

            var existing = FindRoot(avatarRoot);
            if (existing != null) return existing;

            var rootGo = new GameObject(RootName);
            Undo.RegisterCreatedObjectUndo(rootGo, "Create AvatarVCS Root");
            Undo.SetTransformParent(rootGo.transform, avatarRoot.transform, "Create AvatarVCS Root");
            rootGo.transform.localPosition = Vector3.zero;
            rootGo.transform.localRotation = Quaternion.identity;
            rootGo.transform.localScale = Vector3.one;
            var marker = Undo.AddComponent<AvatarVcsRoot>(rootGo);
            marker.AssignGuid(Guid.NewGuid().ToString("N"));

            return rootGo;
        }

        public static GameObject FindRoot(GameObject avatarRoot)
        {
            if (avatarRoot == null) throw new ArgumentNullException(nameof(avatarRoot));

            var child = avatarRoot.transform.Find(RootName);
            if (child != null && child.GetComponent<AvatarVcsRoot>() != null)
                return child.gameObject;

            // Fall back to the marker component if the fast name-based
            // lookup above missed: a manual Hierarchy rename of "[AvatarVCS]"
            // would otherwise make it permanently unfindable by this method,
            // and the next EnsureRoot would spin up a duplicate root next to
            // the (now orphaned) renamed one instead of reusing it.
            for (var i = 0; i < avatarRoot.transform.childCount; i++)
            {
                var candidate = avatarRoot.transform.GetChild(i);
                if (candidate.GetComponent<AvatarVcsRoot>() != null)
                    return candidate.gameObject;
            }

            return null;
        }

        /// <summary>
        /// Walks up from a raw Hierarchy selection to find the avatar it
        /// actually belongs to, so callers never mistake "a container, or
        /// something inside one" for the avatar root itself -- e.g.
        /// selecting an individual outfit prefab instance and hitting
        /// Commit must not silently spin up a brand new, unrelated
        /// "[AvatarVCS]" root nested inside that outfit.
        ///
        /// Returns null if no existing AvatarVCS structure is found
        /// anywhere in the ancestor chain, meaning `from` (or nothing) is a
        /// legitimate candidate for a brand new avatar root.
        /// </summary>
        public static GameObject FindEnclosingAvatarRoot(GameObject from)
        {
            if (from == null) return null;

            // Searches from as well as every ancestor for the "[AvatarVCS]"
            // root's marker component, so this resolves correctly no matter
            // how deep from sits inside a container's own hierarchy.
            // includeInactive: true because a container (or the whole
            // "[AvatarVCS]" root) can legitimately be toggled off.
            var root = from.GetComponentInParent<AvatarVcsRoot>(includeInactive: true);
            return root != null && root.transform.parent != null ? root.transform.parent.gameObject : null;
        }

        /// <summary>
        /// Resolves the avatar to operate on from a raw Hierarchy selection,
        /// for any entry point that turns "whatever's selected" into an
        /// avatarRoot (the GameObject menu, the window's avatar picker). If
        /// selection is already inside an existing AvatarVCS structure (a
        /// container, something inside one, or the "[AvatarVCS]" root
        /// itself), walks up to the actual owning avatar automatically via
        /// FindEnclosingAvatarRoot. If selection has no existing structure
        /// at all, confirms with the user before treating it as a brand new
        /// avatar root -- it could just as easily be a single outfit item as
        /// the avatar itself. Returns null if selection is null or the user
        /// cancels; callers decide what "cancel" means for them (abort vs.
        /// keep whatever was previously selected).
        /// </summary>
        public static GameObject ResolveAvatarRootWithConfirmation(GameObject selection, string actionDescription)
        {
            if (selection == null) return null;

            var enclosing = FindEnclosingAvatarRoot(selection);
            if (enclosing != null) return enclosing;

            if (FindRoot(selection) != null) return selection;

            return EditorUtility.DisplayDialog("Start Tracking This Object?",
                    $"'{selection.name}' has no AvatarVCS history yet. {actionDescription}\n\n"
                    + "If you meant to select your actual avatar's root GameObject (or something inside its existing containers), cancel and select that instead.",
                    "Start Tracking", "Cancel")
                ? selection
                : null;
        }

        /// <summary>
        /// The avatar's stable identity, used to key commit history storage.
        /// Calls EnsureRoot, so a guid is always available even before any
        /// container exists.
        /// </summary>
        public static string GetAvatarGuid(GameObject avatarRoot)
        {
            var root = EnsureRoot(avatarRoot);
            return root.GetComponent<AvatarVcsRoot>().AvatarGuid;
        }

        /// <summary>
        /// Creates a new container directly under root. Containers may not be nested
        /// (design doc 1.3.1) and names must be unique among siblings.
        /// </summary>
        public static GameObject CreateContainer(GameObject root, string containerId)
        {
            if (root == null) throw new ArgumentNullException(nameof(root));
            if (string.IsNullOrEmpty(containerId)) throw new ArgumentException("containerId must not be empty.", nameof(containerId));
            if (root.GetComponent<AvatarVcsRoot>() == null)
                throw new ArgumentException("root must be an AvatarVCS root GameObject (see EnsureRoot).", nameof(root));
            if (root.transform.Find(containerId) != null)
                throw new InvalidOperationException($"A container named '{containerId}' already exists under '{root.name}'.");

            var containerGo = new GameObject(containerId);
            Undo.RegisterCreatedObjectUndo(containerGo, "Create AvatarVCS Container");
            Undo.SetTransformParent(containerGo.transform, root.transform, "Create AvatarVCS Container");
            containerGo.transform.localPosition = Vector3.zero;
            containerGo.transform.localRotation = Quaternion.identity;
            containerGo.transform.localScale = Vector3.one;

            var marker = Undo.AddComponent<AvatarVcsContainer>(containerGo);
            marker.AssignGuid(Guid.NewGuid().ToString("N"));

            return containerGo;
        }

        public static Transform[] GetContainers(GameObject root)
        {
            if (root == null) throw new ArgumentNullException(nameof(root));

            return root.transform.Cast<Transform>()
                .Where(t => t.GetComponent<AvatarVcsContainer>() != null)
                .ToArray();
        }

        /// <summary>
        /// Catches two ways a container structure can violate the tool's
        /// invariants (design doc 1.3.1: containers live directly under
        /// "[AvatarVCS]", are not nested, and are uniquely named) without
        /// going through CreateContainer -- a manual Hierarchy rename or
        /// drag-and-drop can still produce either. Both silently corrupt
        /// commits (duplicate names collide on the same key; a nested
        /// container isn't itself a prefab instance, so it's invisible to
        /// its parent's capture and is lost on the next checkout) rather
        /// than failing loudly, so this is meant to be called right before
        /// a commit is taken.
        /// </summary>
        public static void ValidateContainers(GameObject root)
        {
            if (root == null) throw new ArgumentNullException(nameof(root));

            var containers = GetContainers(root);

            var duplicateNames = containers
                .GroupBy(t => t.name)
                .Where(g => g.Count() > 1)
                .Select(g => g.Key)
                .ToList();
            if (duplicateNames.Count > 0)
                throw new InvalidOperationException(
                    $"Duplicate container name(s) under '{root.name}': {string.Join(", ", duplicateNames)}. "
                    + "Rename one of them before committing -- containerId must be unique.");

            foreach (var container in containers)
            {
                var nested = container.GetComponentsInChildren<AvatarVcsContainer>(includeInactive: true)
                    .FirstOrDefault(c => c.transform != container);
                if (nested != null)
                    throw new InvalidOperationException(
                        $"Container '{container.name}' has another container ('{nested.name}') nested inside it. "
                        + $"Containers cannot be nested -- move '{nested.name}' directly under '{root.name}' instead.");
            }
        }

        /// <summary>
        /// Resolves the GUID of the prefab asset instance derives from, via
        /// GetCorrespondingObjectFromSource. Returns null if instance is not a
        /// prefab instance.
        /// </summary>
        public static string GetPrefabGuid(GameObject instance)
        {
            if (instance == null) throw new ArgumentNullException(nameof(instance));

            var source = PrefabUtility.GetCorrespondingObjectFromSource(instance);
            if (source == null) return null;

            var path = AssetDatabase.GetAssetPath(source);
            return string.IsNullOrEmpty(path) ? null : AssetDatabase.AssetPathToGUID(path);
        }
    }
}
