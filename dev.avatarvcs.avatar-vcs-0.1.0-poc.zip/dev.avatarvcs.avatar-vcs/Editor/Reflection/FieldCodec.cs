using System;
using System.Globalization;
using UnityEditor;
using UnityEngine;

namespace AvatarVcs.Editor.Reflection
{
    /// <summary>
    /// Encodes/decodes SerializedProperty leaf values to/from strings for JSON
    /// storage. Types not listed here (ManagedReference, ExposedReference,
    /// ...) are intentionally unsupported for now (v1 design doc section 10:
    /// add type handlers incrementally, don't front-load all of them).
    /// </summary>
    public static class FieldCodec
    {
        private static readonly CultureInfo Culture = CultureInfo.InvariantCulture;

        // Sane upper bound for an array-size write. Without this, a crafted
        // or corrupted FieldValue targeting "someArray.Array.size" (a real,
        // FindProperty-resolvable SerializedProperty path independent of
        // whether it was ever legitimately captured that way) could set
        // prop.intValue to e.g. 2,000,000,000 and have Unity attempt a huge
        // array resize, hanging or OOM-ing the Editor. No legitimate capture
        // from this tool's own ComponentCapturer produces anything remotely
        // close to this.
        private const int MaxArraySize = 100_000;

        public static bool TryEncode(SerializedProperty prop, out string value, out string type)
        {
            switch (prop.propertyType)
            {
                // Integer covers both int and 64-bit (long/ulong) fields;
                // .intValue silently truncates a long to 32 bits, so the
                // underlying field type (prop.type) decides which accessor
                // to use. ulong's bit pattern round-trips through .longValue
                // like any other 64-bit storage; only the string
                // representation needs to reinterpret it as unsigned.
                case SerializedPropertyType.Integer when prop.type == "ulong":
                    value = unchecked((ulong)prop.longValue).ToString(Culture);
                    type = "ulong";
                    return true;
                case SerializedPropertyType.Integer when prop.type == "long":
                    value = prop.longValue.ToString(Culture);
                    type = "long";
                    return true;
                case SerializedPropertyType.Integer:
                case SerializedPropertyType.ArraySize:
                    value = prop.intValue.ToString(Culture);
                    type = "int";
                    return true;
                case SerializedPropertyType.Boolean:
                    value = prop.boolValue ? "true" : "false";
                    type = "bool";
                    return true;
                case SerializedPropertyType.Float:
                    value = prop.floatValue.ToString("R", Culture);
                    type = "float";
                    return true;
                case SerializedPropertyType.String:
                    value = prop.stringValue;
                    type = "string";
                    return true;
                case SerializedPropertyType.Color:
                    var c = prop.colorValue;
                    value = Join(c.r, c.g, c.b, c.a);
                    type = "color";
                    return true;
                case SerializedPropertyType.LayerMask:
                    value = prop.intValue.ToString(Culture);
                    type = "layerMask";
                    return true;
                case SerializedPropertyType.Enum:
                    value = prop.intValue.ToString(Culture);
                    type = "enum";
                    return true;
                case SerializedPropertyType.Character:
                    value = prop.intValue.ToString(Culture);
                    type = "character";
                    return true;
                case SerializedPropertyType.Vector2:
                    var v2 = prop.vector2Value;
                    value = Join(v2.x, v2.y);
                    type = "vector2";
                    return true;
                case SerializedPropertyType.Vector3:
                    var v3 = prop.vector3Value;
                    value = Join(v3.x, v3.y, v3.z);
                    type = "vector3";
                    return true;
                case SerializedPropertyType.Vector4:
                    var v4 = prop.vector4Value;
                    value = Join(v4.x, v4.y, v4.z, v4.w);
                    type = "vector4";
                    return true;
                case SerializedPropertyType.Vector2Int:
                    var v2i = prop.vector2IntValue;
                    value = $"{v2i.x},{v2i.y}";
                    type = "vector2Int";
                    return true;
                case SerializedPropertyType.Vector3Int:
                    var v3i = prop.vector3IntValue;
                    value = $"{v3i.x},{v3i.y},{v3i.z}";
                    type = "vector3Int";
                    return true;
                case SerializedPropertyType.Rect:
                    var r = prop.rectValue;
                    value = Join(r.x, r.y, r.width, r.height);
                    type = "rect";
                    return true;
                case SerializedPropertyType.RectInt:
                    var ri = prop.rectIntValue;
                    value = $"{ri.x},{ri.y},{ri.width},{ri.height}";
                    type = "rectInt";
                    return true;
                case SerializedPropertyType.Bounds:
                    var b = prop.boundsValue;
                    value = Join(b.center.x, b.center.y, b.center.z, b.size.x, b.size.y, b.size.z);
                    type = "bounds";
                    return true;
                case SerializedPropertyType.BoundsInt:
                    var bi = prop.boundsIntValue;
                    value = $"{bi.position.x},{bi.position.y},{bi.position.z},{bi.size.x},{bi.size.y},{bi.size.z}";
                    type = "boundsInt";
                    return true;
                case SerializedPropertyType.Quaternion:
                    var q = prop.quaternionValue;
                    value = Join(q.x, q.y, q.z, q.w);
                    type = "quaternion";
                    return true;
                case SerializedPropertyType.AnimationCurve:
                    value = EncodeAnimationCurve(prop.animationCurveValue);
                    type = "animationCurve";
                    return true;
                case SerializedPropertyType.Gradient:
                    value = EncodeGradient(prop.gradientValue);
                    type = "gradient";
                    return true;
                default:
                    value = null;
                    type = null;
                    return false;
            }
        }

        /// <summary>
        /// Never throws, regardless of how malformed value is (truncated,
        /// wrong component count, non-numeric, ...) -- value ultimately comes
        /// from commit JSON on disk, which can be corrupted (crash mid-write,
        /// bad merge) independent of any deliberate tampering. Callers rely
        /// on a false return to warn-and-skip a field rather than aborting
        /// whatever destructive operation (e.g. checkout) is already
        /// underway.
        /// </summary>
        public static bool TryDecode(SerializedProperty prop, string type, string value)
        {
            try
            {
                return TryDecodeCore(prop, type, value);
            }
            catch (Exception e) when (e is FormatException or OverflowException or IndexOutOfRangeException or ArgumentNullException)
            {
                return false;
            }
        }

        private static bool TryDecodeCore(SerializedProperty prop, string type, string value)
        {
            switch (type)
            {
                case "int":
                case "layerMask":
                case "enum":
                case "character":
                {
                    var intValue = int.Parse(value, Culture);
                    if (prop.propertyType == SerializedPropertyType.ArraySize && (intValue < 0 || intValue > MaxArraySize))
                        return false;
                    prop.intValue = intValue;
                    return true;
                }
                case "long":
                    prop.longValue = long.Parse(value, Culture);
                    return true;
                case "ulong":
                    prop.longValue = unchecked((long)ulong.Parse(value, Culture));
                    return true;
                case "bool":
                    prop.boolValue = value == "true";
                    return true;
                case "float":
                    prop.floatValue = float.Parse(value, Culture);
                    return true;
                case "string":
                    prop.stringValue = value;
                    return true;
                case "color":
                {
                    var p = ParseFloats(value);
                    prop.colorValue = new Color(p[0], p[1], p[2], p[3]);
                    return true;
                }
                case "vector2":
                {
                    var p = ParseFloats(value);
                    prop.vector2Value = new Vector2(p[0], p[1]);
                    return true;
                }
                case "vector3":
                {
                    var p = ParseFloats(value);
                    prop.vector3Value = new Vector3(p[0], p[1], p[2]);
                    return true;
                }
                case "vector4":
                {
                    var p = ParseFloats(value);
                    prop.vector4Value = new Vector4(p[0], p[1], p[2], p[3]);
                    return true;
                }
                case "vector2Int":
                {
                    var p = ParseInts(value);
                    prop.vector2IntValue = new Vector2Int(p[0], p[1]);
                    return true;
                }
                case "vector3Int":
                {
                    var p = ParseInts(value);
                    prop.vector3IntValue = new Vector3Int(p[0], p[1], p[2]);
                    return true;
                }
                case "rect":
                {
                    var p = ParseFloats(value);
                    prop.rectValue = new Rect(p[0], p[1], p[2], p[3]);
                    return true;
                }
                case "rectInt":
                {
                    var p = ParseInts(value);
                    prop.rectIntValue = new RectInt(p[0], p[1], p[2], p[3]);
                    return true;
                }
                case "bounds":
                {
                    var p = ParseFloats(value);
                    prop.boundsValue = new Bounds(new Vector3(p[0], p[1], p[2]), new Vector3(p[3], p[4], p[5]));
                    return true;
                }
                case "boundsInt":
                {
                    var p = ParseInts(value);
                    prop.boundsIntValue = new BoundsInt(new Vector3Int(p[0], p[1], p[2]), new Vector3Int(p[3], p[4], p[5]));
                    return true;
                }
                case "quaternion":
                {
                    var p = ParseFloats(value);
                    prop.quaternionValue = new Quaternion(p[0], p[1], p[2], p[3]);
                    return true;
                }
                case "animationCurve":
                    prop.animationCurveValue = DecodeAnimationCurve(value);
                    return true;
                case "gradient":
                    prop.gradientValue = DecodeGradient(value);
                    return true;
                default:
                    return false;
            }
        }

        /// <summary>
        /// "{preWrapMode},{postWrapMode}|{key1};{key2};..." where each key is
        /// "time,value,inTangent,outTangent,inWeight,outWeight,weightedMode".
        /// </summary>
        private static string EncodeAnimationCurve(AnimationCurve curve)
        {
            var keys = curve.keys;
            var keyParts = new string[keys.Length];
            for (var i = 0; i < keys.Length; i++)
            {
                var k = keys[i];
                keyParts[i] = string.Join(",", new[]
                {
                    k.time.ToString("R", Culture),
                    k.value.ToString("R", Culture),
                    k.inTangent.ToString("R", Culture),
                    k.outTangent.ToString("R", Culture),
                    k.inWeight.ToString("R", Culture),
                    k.outWeight.ToString("R", Culture),
                    ((int)k.weightedMode).ToString(Culture),
                });
            }

            return $"{(int)curve.preWrapMode},{(int)curve.postWrapMode}|{string.Join(";", keyParts)}";
        }

        private static AnimationCurve DecodeAnimationCurve(string value)
        {
            var parts = value.Split('|');
            var wrapModes = parts[0].Split(',');
            var preWrapMode = (WrapMode)int.Parse(wrapModes[0], Culture);
            var postWrapMode = (WrapMode)int.Parse(wrapModes[1], Culture);

            var keyParts = parts.Length > 1 && parts[1].Length > 0
                ? parts[1].Split(';')
                : Array.Empty<string>();
            var keys = new Keyframe[keyParts.Length];
            for (var i = 0; i < keyParts.Length; i++)
            {
                var f = keyParts[i].Split(',');
                keys[i] = new Keyframe(
                    float.Parse(f[0], Culture),
                    float.Parse(f[1], Culture),
                    float.Parse(f[2], Culture),
                    float.Parse(f[3], Culture),
                    float.Parse(f[4], Culture),
                    float.Parse(f[5], Culture))
                {
                    weightedMode = (WeightedMode)int.Parse(f[6], Culture),
                };
            }

            return new AnimationCurve(keys) { preWrapMode = preWrapMode, postWrapMode = postWrapMode };
        }

        /// <summary>
        /// "{mode}|{colorKey1};{colorKey2};...|{alphaKey1};{alphaKey2};..."
        /// where a color key is "r,g,b,time" and an alpha key is "alpha,time".
        /// Alpha is carried separately (GradientAlphaKey), not through a
        /// color key's own alpha component, which Unity ignores.
        /// </summary>
        private static string EncodeGradient(Gradient gradient)
        {
            var colorParts = new string[gradient.colorKeys.Length];
            for (var i = 0; i < gradient.colorKeys.Length; i++)
            {
                var k = gradient.colorKeys[i];
                colorParts[i] = string.Join(",", new[]
                {
                    k.color.r.ToString("R", Culture), k.color.g.ToString("R", Culture),
                    k.color.b.ToString("R", Culture), k.time.ToString("R", Culture),
                });
            }

            var alphaParts = new string[gradient.alphaKeys.Length];
            for (var i = 0; i < gradient.alphaKeys.Length; i++)
            {
                var k = gradient.alphaKeys[i];
                alphaParts[i] = $"{k.alpha.ToString("R", Culture)},{k.time.ToString("R", Culture)}";
            }

            return $"{(int)gradient.mode}|{string.Join(";", colorParts)}|{string.Join(";", alphaParts)}";
        }

        private static Gradient DecodeGradient(string value)
        {
            var parts = value.Split('|');
            var mode = (GradientMode)int.Parse(parts[0], Culture);

            var colorKeyParts = parts[1].Length > 0 ? parts[1].Split(';') : Array.Empty<string>();
            var colorKeys = new GradientColorKey[colorKeyParts.Length];
            for (var i = 0; i < colorKeyParts.Length; i++)
            {
                var f = colorKeyParts[i].Split(',');
                colorKeys[i] = new GradientColorKey(
                    new Color(float.Parse(f[0], Culture), float.Parse(f[1], Culture), float.Parse(f[2], Culture)),
                    float.Parse(f[3], Culture));
            }

            var alphaKeyParts = parts[2].Length > 0 ? parts[2].Split(';') : Array.Empty<string>();
            var alphaKeys = new GradientAlphaKey[alphaKeyParts.Length];
            for (var i = 0; i < alphaKeyParts.Length; i++)
            {
                var f = alphaKeyParts[i].Split(',');
                alphaKeys[i] = new GradientAlphaKey(float.Parse(f[0], Culture), float.Parse(f[1], Culture));
            }

            var gradient = new Gradient();
            gradient.SetKeys(colorKeys, alphaKeys);
            gradient.mode = mode;
            return gradient;
        }

        private static string Join(params float[] values) =>
            string.Join(",", Array.ConvertAll(values, v => v.ToString("R", Culture)));

        private static float[] ParseFloats(string value) =>
            Array.ConvertAll(value.Split(','), s => float.Parse(s, Culture));

        private static int[] ParseInts(string value) =>
            Array.ConvertAll(value.Split(','), s => int.Parse(s, Culture));
    }
}
